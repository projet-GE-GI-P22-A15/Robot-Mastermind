#include "matrixLED.h"
#include <libarmus.h>
#include "valeurs.h"

//CODE DE MATRICE ICI

void afficheMatrixDEL(){
	// A voir si recois un tableau mais bon, affiche les couleurs sur la matrix de del
}

int formatTableauMatrix(){
	// A voir comment utiliser cette fonction

	return 1;
}

