/** @file capteurs.h
 *  @brief Les prototypes de function pour les capteurs.
 *
 *  @author Marc-Antoine Lalonde (Bloodae) 
 *  @author Pascal Vaillancourt (scoremoregoals)
 *  @author Anthony Parris (MrParris)
 *  
 *  @bug No known bugs.
 */

#ifndef LOGIQUE_H_
#define LOGIQUE_H_

//FONCTIONS POUR LA LOGIQUE DU ROBOT

/**
 * @brief [brief description]
 * @details [long description]
 * @return [description]
 */
int lineFollower();

/**
 * @brief [brief description]
 * @details [long description]
 * @return [description]
 */
int mainCRJ();

/**
 * @brief [brief description]
 * @details [long description]
 * @return [description]
 */
int mainCapteur();


#endif // LOGIQUE_H_
