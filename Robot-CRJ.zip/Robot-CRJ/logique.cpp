#include "logique.h"
#include <libarmus.h>
#include "valeurs.h"
#include "capteurs.h"
#include "pid.h"
#include "rotation.h"

//code pour logique ici
int mainCRJ(){
	//ne pas faire une boucle while, car je fais letat du fonctionnement dans le main!!!!!! et la boucle est dans le main
	//Si return == 1 DESTROY LE THREAD, si 0 sa continue le thread

	//faire le code general de notre robot final

	THREAD_MSleep(10);	// Execute a tous les 10ms
	return 0;
}

int mainCapteur(){
	//ne pas faire une boucle while, car je fais letat du fonctionnement dans le main!!!!!! et la boucle est dans le main
	//Si return == 1 DESTROY LE THREAD, si 0 sa continue le thread

	//appeller toutes les fonctions de capteurs!!!

	THREAD_MSleep(50);	// Execute a tous les 50ms
	return 0;
}

int lineFollower() {
	if (ligneCentre == 0) {
		return 2;
	} else if (ligneGauche == 0) {
		return 1;
	} else if (ligneDroite == 0) {
		return 3;
	} else {
		return 0;
	}
}

