/** @file capteurs.h
 *  @brief Les prototypes de function pour les capteurs.
 *
 *  @author Pascal Vaillancourt (scoremoregoals)
 *  
 *  @bug No known bugs.
 */

#ifndef MATRIXLED_H_
#define MATRIXLED_H_

/**
 * @brief [brief description]
 * @details [long description]
 */
void afficheMatrixDEL();

/**
 * @brief [brief description]
 * @details [long description]
 * @return [description]
 */
int formatTableauMatrix();


#endif // MATRIXLED_H_